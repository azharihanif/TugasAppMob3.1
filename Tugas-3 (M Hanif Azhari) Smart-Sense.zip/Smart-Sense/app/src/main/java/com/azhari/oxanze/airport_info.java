package com.azhari.oxanze;

import android.app.ListActivity;
import android.app.SearchManager;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class airport_info extends ListActivity {
    protected void onCreate(Bundle icicle) {
        super.onCreate(icicle);
        String[] listmenu = new String[]{"Route (Google Maps)", "Official Website", "Call Center",
                "More Info (Google Search)"};
        this.setListAdapter(new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1, listmenu));
    }

    protected void onListItemClick(ListView l, View v, int position, long id) {
        super.onListItemClick(l, v, position, id);
        Object o = this.getListAdapter().getItem(position);
        String pilihan = o.toString();
        tampilkanpilihan(pilihan);
    }

    private void tampilkanpilihan(String pilihan) {
        try { Intent a = null;
            if (pilihan.equals("Route (Google Maps)"))
            { String lokasirs = "google.navigation:q=0.46474296266498066, 101.44770023955996";
                a = new Intent(Intent.ACTION_VIEW, Uri.parse(lokasirs)); }

            else if (pilihan.equals("Official Website"))
            { String website = "https://sultansyarifkasim2-airport.co.id/";
                a = new Intent(Intent.ACTION_VIEW, Uri.parse(website)); }

            else if (pilihan.equals("Call Center"))
            { String nomortel = "tel:0761-674694";
                a = new Intent(Intent.ACTION_DIAL, Uri.parse(nomortel)); }

            else if (pilihan.equals("More Info (Google Search)"))
            { a = new Intent(Intent.ACTION_WEB_SEARCH);
                a.putExtra(SearchManager.QUERY, "Bandara Sultan Syarif Kasim II Pekanbaru"); }

            startActivity(a);
            }

        catch (Exception e)
            { e.printStackTrace();}
    }
}
